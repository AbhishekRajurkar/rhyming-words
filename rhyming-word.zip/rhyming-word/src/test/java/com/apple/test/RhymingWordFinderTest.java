package com.apple.test;

import org.junit.Test;

import java.util.HashSet;

public class RhymingWordFinderTest {

    @Test
    public void testFindRhymingWordsWhenNoneMatch(){
        RhymingWordFinder rhymingWordFinder = RhymingWordFinder.getInstance();
        //given
        String[] inputList = {"disputing", "Polluting", "Commuting", "Diluting", "recruiting", "Drooping",  "bicycle", "Fish"};
        String inputWord = "orange";

        //when
        HashSet<String> rhymingWords = rhymingWordFinder.findRhymingWords(inputWord, inputList);

        //then
        assert(rhymingWords.isEmpty());
    }

    @Test
    public void testFindRhymingWordsLargeDiffInWordLength(){
        RhymingWordFinder rhymingWordFinder = RhymingWordFinder.getInstance();
        String[] inputList = {"ox", "Fish"};
        String inputWord = "abseldjxedox";

        //when
        HashSet<String> rhymingWords = rhymingWordFinder.findRhymingWords(inputWord, inputList);

        //then
        assert(rhymingWords.isEmpty());
    }

    @Test
    public void testFindRhymingWordsWithMaxCharMatch(){
        RhymingWordFinder rhymingWordFinder = RhymingWordFinder.getInstance();
        //given
        String[] inputList = {"disputing", "Polluting", "Commuting", "Diluting", "recruiting", "Drooping",  "bicycle", "Fish"};
        String inputWord = "Computing";

        //when
        HashSet<String> rhymingWords = rhymingWordFinder.findRhymingWords(inputWord, inputList);

        //then
        assert(rhymingWords.contains("disputing"));
    }

    @Test
    public void testFindRhymingWordsWithManyWordsHavingSameNumCharMatch(){
        RhymingWordFinder rhymingWordFinder = RhymingWordFinder.getInstance();
        //given
        String[] inputList = {"disputing", "Polluting", "Commuting", "Diluting", "recruiting", "Drooping",  "bicycle", "Fish"};
        String inputWord = "convoluting";

        //when
        HashSet<String> rhymingWords = rhymingWordFinder.findRhymingWords(inputWord, inputList);

        //then
        HashSet<String> expected = new HashSet<>();
        expected.add("Polluting");
        expected.add("Diluting");

        assert(rhymingWords.containsAll(expected));
    }
}
