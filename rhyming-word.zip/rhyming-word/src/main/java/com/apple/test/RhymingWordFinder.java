package com.apple.test;

import java.util.HashSet;
import java.util.TreeMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class RhymingWordFinder {

    private static final Logger logger = LogManager.getLogger(RhymingWordFinder.class);
    private static final double MIN_MATCH_PERCENTAGE = 0.33;
    private final TreeMap<Integer, HashSet<String>> rhymingWordsMap;

    private RhymingWordFinder(){
        rhymingWordsMap = new TreeMap<>();
    }
    public static RhymingWordFinder getInstance(){
        return new RhymingWordFinder();
    }

    public HashSet<String> findRhymingWords(String inputWord, String[] wordList) {
        String reverseInputWord = reverse(inputWord).toLowerCase();
        for(String word: wordList){
            String reverseWord = reverse(word).toLowerCase();
            int smallerWordLength = Math.min(reverseWord.length(), reverseInputWord.length());
            int longerWordLength = Math.max(reverseWord.length(), reverseInputWord.length());
            int matchingCharCount = getMatchingCharCount(reverseWord, reverseInputWord, smallerWordLength);
            logger.info("Matching characters between {} ,{}, are {}", inputWord, word, matchingCharCount);
            addWordToRhymingMap(word, longerWordLength, matchingCharCount);
        }
    return getRhymingWordsWithMaxMatch();
}

    private void addWordToRhymingMap(String word, float longerWordLength, Integer matchingCharCount) {
        double matchingPercentage = (1 -  (longerWordLength - (float) matchingCharCount) / longerWordLength);
        logger.debug("Match percentage are {}", matchingPercentage);
        if(matchingPercentage > MIN_MATCH_PERCENTAGE){
            if (!rhymingWordsMap.containsKey(matchingCharCount)){
                rhymingWordsMap.put(matchingCharCount, new HashSet<>());
            }
            rhymingWordsMap.get(matchingCharCount).add(word);
        }
    }

    private HashSet<String> getRhymingWordsWithMaxMatch() {
        if(!rhymingWordsMap.isEmpty()){
            int maxCharMatch =  rhymingWordsMap.lastKey();
            return rhymingWordsMap.get(maxCharMatch);
        }
        else return new HashSet<>();
    }

    private static int getMatchingCharCount(String reverseWord, String reverseInputWord, int smallerWordLength) {
        int matchingCharCount = 0 ;
        for(int i = 0; i < smallerWordLength; i++){
            if(reverseWord.charAt(i) == reverseInputWord.charAt(i)){
                matchingCharCount++;
            }else
                break;
        }
        return matchingCharCount;
    }

    private static String reverse(String s) {
        StringBuilder sb = new StringBuilder(s);
        sb.reverse();
        return new String(sb);
    }

}
