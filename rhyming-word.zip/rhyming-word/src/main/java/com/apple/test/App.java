package com.apple.test;

import java.util.HashSet;
import java.util.Scanner;

public class App 
{
    public static void main( String[] args )
    {

        Scanner scanner = new Scanner(System.in);
        RhymingWordFinder rhymingWordFinder = RhymingWordFinder.getInstance();

        while(true){
            System.out.print("Enter word: ");

            String inputWord = scanner.nextLine();
            System.out.print("Enter comma (,) separated list of words: ");
            String inputWordList = scanner.nextLine();
            String[] wordList = inputWordList.split(",");
            HashSet<String> rhymingWords = rhymingWordFinder.findRhymingWords(inputWord, wordList);
            System.out.print(rhymingWords);
            System.out.println();
            rhymingWords.clear();
            System.out.print("Do you want to continue ? N: No ; Press any key: Yes: ");
            String choice = scanner.nextLine();

            if(choice.equalsIgnoreCase("N")){
                break;
            }

        }
        scanner.close();
        System.out.println("exiting");
    }


}
