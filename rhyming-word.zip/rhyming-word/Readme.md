To run this program you need Java 11 or above. 
Run App.Java - This accepts command line arguments, example shown below. 

Enter word: orange
Enter comma (,) separated list of words: Computing, disputing, recruiting, Polluting, fish
[]
Do you want to continue ? N: No ; Press any key: Yes 


How does it work ? 

Input word is compared with each word received in word list in reverse order(by reversing the words).
Count the number of matching character 
And based on the length of the longest word and number of matching chars a percentage match is calculated.
I am assuming here that for any 2 words to rhyme at least 1/3 or 33.33% of ending chars should match.
Once the word from list matches above criteria it's added to map with key as matching chars and value as Set of words.
Note -  Set is used to avoid duplicates received in input word list.

Map used is a Tree Map(which internally uses Red Black BST) that keep the objects in order - in this case the max number of matching chars would be last key.
If there is no word in the list that matches 33.33 % criteria above, map would be empty.

Finally the Set with max matching Chars is returned. 

reversing a word - I have used StringBuilder - This allows us reverse String in O(n). n -> length of string.
comparing reversed words - iterating over smaller word length and break on first char mis match - say smaller word length being m - in worst case O(m) but as I am doing it for all the words received in input list. 
TreeMap has complexity of O(logN) for insertion and lookup
